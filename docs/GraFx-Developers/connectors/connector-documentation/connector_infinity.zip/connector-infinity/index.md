# Media Connector for **Infinity**

|  | Connector Type |
| --- | --- |
|  | Built-in |
| | Built by CHILI publish |
| :fontawesome-regular-square-check:  | Third party |

[See Connector Types](/GraFx-Studio/concepts/connectors/#types-of-connectors)

## Support

Where and how should users go for support inqueries.

Contact [Infinity](https://chili-publish.com) for questions

## Installation

How to deploy or install a connector to your environment?

[See Installation Through Connector Hub](/GraFx-Studio/guides/connector-hub/)

## Infinity Configuration 

Consult your [Infinity documentation](https://example.com) or Infinity System Admin to obtain the correct values for the fields.

- **OAuth settings**
``` html
https://<Infinity-path>/en-us/admin/oauthclients
```

- **Redirect URL** (only used if grafx config is Authorization Code):
``` html
https://<env-name>.chili-publish.online/grafx/api/v1/environment/<env-name>/connectors/<connector-id>/auth/oauth-authorization-code/redirect
```
- **Any Other Setting** on your side
```html
Add info to the setting
```

## CHILI GraFx Connector Configuration 

From the overview of Environments, click on "Settings" on the right to your environment, where you want to install or configure the Connector.

![screenshot-full](infinity12.jpg)

Then click the installed Connector to access the configuration.

![screenshot-full](infinity11.png)

### Base Configuration

Your instance of the Connector needs to know which **Infinity** instance it should communicate with and how to authenticate.

![screenshot-full](infinity01.png)

### Authentication

Select your type of authentication:

**Supported on Server:** OAuth 2.0 Resource Owner Password  
This is the flow where username and password are needed. It makes all requests as that specific user.

**Supported on Browser:** OAuth 2.0 Authorization Code (Browser only)

![screenshot](infinity02.png)

- **Client ID** and **Client Secret**: These are [customer-specific credentials](https://example.com) provided by the **Infinity** Admin when creating integrations within **Infinity**.
- **Username** and **Password**: User-specific credentials for authentication.
- **Token Endpoint**: Developer-oriented settings available in **Infinity** documentation. These settings are generic for all **Infinity** clients.
- **Scope**: Consult your **Infinity** Admin to determine the appropriate scope.

You can configure separate authentication for machine-to-machine and browser use cases or use the same setup for both.

![screenshot-full](infinity04.png)

- **Authorization Endpoint** https://example.com/oauth/authorize
- **Token Endpoint** https://example.com/oauth/token

!!! info
    For **Infinity** different values and settings might be required

Consult your **Infinity** System Admin for assistance in configuring these fields.

### Server Authentication

The credentials used for machine-to-machine authentication determine the governance on assets in automation workflows. 

This means that if the credentials restrict access to specific assets, only those assets will be available during batch processing.

### Browser Authentication or Impersonation

GraFx Studio accesses assets available in your Media Provider via impersonation, where the credentials configured for the connector determine which assets are visible to the user in the template.

**Impersonation** is the process of granting GraFx Studio users access to the DAM system using pre-configured credentials. This ensures seamless integration while respecting the DAM's security and governance rules.

## Using Assets from Your **Infinity** System

### Place Assets in Your Template

- Select the **Infinity** Connector.

![screenshot-full](infinity06.png)

![screenshot-full](infinity07.png)

![screenshot-full](infinity08.png)

Depending on the configuration, you may need to authenticate.

![screenshot-full](infinity09.png)

- Once authenticated, **Infinity** assets behave like any other asset in GraFx Studio.

### Image Variables

When using [image variables](/GraFx-Studio/guides/template-variables/assign/#assign-template-variable-to-image-frame), you will see the same list of assets when selecting an image.

![screenshot-full](infinity13.png)

### Configuration Options

#### Introduction

To filter the assets suggested to template users, you can use categories, keywords, or other search parameters.

**Infinity** supports search queries through its query language. Consult the [**Infinity** Documentation](https://example.com) or your **Infinity** Administrator for guidance.

#### How To

Queries are set at the variable level.

Set the query value in the connector settings.

![screenshot-full](infinity14.png)

For more dynamic queries, you can use [variables](/GraFx-Studio/concepts/variables/), [actions](/GraFx-Studio/concepts/actions/), and [GraFx Genie](/GraFx-Studio/concepts/grafx-genie/) to automate and refine your queries.

#### Other Configuration Options

- **Show Only Approved Assets**: Displays only assets that have been approved in **Infinity**.
- **Locale**: Filters assets by region or language.

!!! info
    These settings will vary, depending on what you added in your connector